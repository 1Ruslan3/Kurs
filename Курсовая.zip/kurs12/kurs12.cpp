﻿ #include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <sstream>
#include <ctime>



struct Message
{
    std::string userName;
    std::string time;
    std::string text;

    Message(const std::string& user, const std::string& t, const std::string& msg)
        : userName(user), time(t), text(msg) {}

    friend std::ostream& operator<<(std::ostream& os, const Message& msg)
    {
        os << msg.userName << " " << msg.time <<  msg.text;
        return os;
    }
};


struct MessageComparator
{
    bool operator()(const Message* lhs, const Message* rhs) const 
    {
        if (lhs->userName != rhs->userName) 
        {
            return lhs->userName < rhs->userName;
        }
        return lhs->time < rhs->time;
    }
};


class MessageProcessor final 
{
private:
    std::set<Message*, MessageComparator> messages; 

public:

    MessageProcessor() = default;

    MessageProcessor(const MessageProcessor& other)
    {
        for (auto msg : other.messages)
        {
            messages.insert(new Message(*msg));
        }
    }
    MessageProcessor(MessageProcessor&& other) noexcept
        : messages(std::move(other.messages)) {}

    MessageProcessor& operator=(const MessageProcessor& other)
    {
        if (this != &other)
        {
        
            for (auto msg : messages)
            {
                delete msg;
            }
            messages.clear();

     
            for (auto msg : other.messages)
            {
                messages.insert(new Message(*msg));
            }
        }
        return *this;
    }

    MessageProcessor& operator=(MessageProcessor&& other) noexcept
    {
        if (this != &other)
        {
            for (auto msg : messages)
            {
                delete msg;
            }
            messages.clear();

            messages = std::move(other.messages);
        }
        return *this;
    }

    ~MessageProcessor() 
    {
        for (auto msg : messages) 
        {
            delete msg;
        }
        messages.clear(); 
    }
public:

    void addMessage(const std::string& user, const std::string& time, const std::string& text)
    {
        Message* msg = new Message(user, time, text);
        messages.insert(msg);
    }

    // Вывод всех сообщений заданного пользователя
    void printUserMessages(const std::string& user) const 
    {
        for (auto msg : messages) 
        {
            if (msg->userName == user) 
            {
                std::cout << *msg << std::endl;
            }
        }
    }

    // Вывод сообщений заданного пользователя для заданного временного интервала
    void printUserMessagesInTimeInterval(const std::string& user, const std::string& startTime, const std::string& endTime) const 
    {
        for (auto msg : messages) 
        {
            if (msg->userName == user && msg->time >= startTime && msg->time <= endTime)
            {
                std::cout << *msg << std::endl;
            }
        }
    }

    // Вывод всех сообщений из заданного временного интервала
    void printMessagesInTimeInterval(const std::string& startTime, const std::string& endTime) const
    {
        for (auto msg : messages) 
        {
            if (msg->time >= startTime && msg->time <= endTime) 
            {
                std::cout << *msg << std::endl;
            }
        }
    }

    // Удаление сообщения
    void deleteMessage(const std::string& user, const std::string& time) 
    {
        for (auto it = messages.begin(); it != messages.end(); ++it)
        {
            if ((*it)->userName == user && (*it)->time == time) 
            {
                delete* it;
                messages.erase(it);
                return;
            }
        }
    }

    // Удаление всех сообщений заданного пользователя
    void deleteUserMessages(const std::string& user) 
    {
        for (auto it = messages.begin(); it != messages.end();)
        {
            if ((*it)->userName == user) 
            {
                delete* it;
                it = messages.erase(it);
            }
            else
            {
                ++it;
            }
        }
    }
};

int main() 
{
    MessageProcessor processor;
    std::fstream inputFile("messages.txt");

    if (!inputFile.is_open()) 
    {
        std::cout << "Failed to open the file." << std::endl;
        return 1;
    }

    std::string line;
    while (getline(inputFile, line)) 
    {
        std::stringstream ss(line);
        std::string user, time, messageText;
        ss >> user;
        ss >> time;
        getline(ss, messageText); // Считываем оставшуюся часть строки как текст сообщения
        processor.addMessage(user, time, messageText);
    }
    inputFile.close(); 

    // Пример использования методов класса MessageProcessor
    std::cout << "All messages of user 'Alice':" << std::endl;
    processor.printUserMessages("Alice");


    std::cout << "\nMessages of user 'Bob' between 10:00:00 and 12:00:00:" << std::endl; 
    processor.printUserMessagesInTimeInterval("Bob", "10:00:00", "12:00:00"); 
    
    std::cout << "\nAll messages between 09:00:00 and 13:00:00:" << std::endl;
    processor.printMessagesInTimeInterval("09:00:00", "13:00:00"); 

    // Пример удаления сообщения и всех сообщений пользователя
    processor.deleteMessage("Alice", "11:30:00");
    processor.deleteUserMessages("Bob");

    return 0;
}
